<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type') ?>; charset=<?php bloginfo('charset') ?>" />
<title><?php wp_title( '|', true, 'right' ); bloginfo( 'name' ); ?></title>

<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>

	<!-- Coda-Slider Stylesheets -->
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/coda-slider-2/stylesheets/reset.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/coda-slider-2/stylesheets/coda-slider-2.0.css" type="text/css" media="screen" />
	<!-- End Coda-Slider Stylesheets -->
	
	<!-- Begin Coda-Slider JavaScript -->
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/coda-slider-2/javascripts/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/coda-slider-2/javascripts/jquery.easing.1.3.js"></script>
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/coda-slider-2/javascripts/jquery.coda-slider-2.0.js"></script>
		 <script type="text/javascript">
			$().ready(function() {
				$('#coda-slider-1').codaSlider();
			});
		 </script>
	<!-- End Coda-Slider JavaScript -->
	
	<!-- JQuery Slider Stylesheets -->
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/jqslider2/css/jqueryprodslider.css" type="text/css" media="screen" />
	
	<!-- End of JQuery Slider Stylesheets -->
	
	<!-- JQuery Slider JavaScript -->
		<link type="text/css" href="<?php bloginfo('template_url'); ?>/jqslider2/css/overcast/jquery-ui-1.8.16.custom.css" rel="stylesheet" />	
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/jqslider2/js/jquery-ui-1.8.16.custom.min.js"></script>
		
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/jqslider2/js/jquery-product-slider.js"></script>
	<!-- End of JQuery Slider JavaScript -->

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url') ?>" type="text/css" media="screen" />
<!--[if IE 6]><link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.ie6.css" type="text/css" media="screen" /><![endif]-->
<!--[if IE 7]><link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.ie7.css" type="text/css" media="screen" /><![endif]-->
<?php if(WP_VERSION < 3.0): ?>
<link rel="alternate" type="application/rss+xml" title="<?php printf(__('%s RSS Feed', THEME_NS), get_bloginfo('name')); ?>" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php printf(__('%s Atom Feed', THEME_NS), get_bloginfo('name')); ?>" href="<?php bloginfo('atom_url'); ?>" />
<?php endif; ?>
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php
remove_action('wp_head', 'wp_generator');
wp_enqueue_script('jquery');
if ( is_singular() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}
wp_head(); ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/script.js"></script>
</head>
<body <?php if(function_exists('body_class')) body_class(); ?>>
<div id="art-page-background-middle-texture">
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="cleared reset-box"></div>
    <div class="art-nav">
    	<div class="art-nav-l"></div>
    	<div class="art-nav-r"></div>
        <div class="art-nav-outer">
        <div class="art-nav-wrapper">
        <div class="art-nav-inner">
    	<?php 
    		echo theme_get_menu(array(
    				'source' => theme_get_option('theme_menu_source'),
    				'depth' => theme_get_option('theme_menu_depth'),
    				'menu' => 'primary-menu',
    				'class' => 'art-hmenu'	
    			)
    		);
    	?>
        </div>
        </div>
        </div>
    </div>
    <div class="cleared reset-box"></div>
    <div class="art-header">
        <div class="art-header-clip">
        <div class="art-header-center">
            <div class="art-header-jpeg"></div>
        </div>
        </div>
    <div class="art-header-wrapper">
    <div class="art-header-inner">
        <div class="art-headerobject"></div>
        <div class="art-logo">
        </div>
    </div>
    </div>
    </div>
    <div class="cleared reset-box"></div>
    <div class="art-sheet">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body">
