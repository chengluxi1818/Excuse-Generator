<?php if ( !theme_dynamic_sidebar( 'footer' ) ) : ?>
<?php $style = theme_get_option('theme_sidebars_style_footer'); ?>



<?php endif; ?>